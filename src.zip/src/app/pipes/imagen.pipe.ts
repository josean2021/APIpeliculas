import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'imagen'
})

export class ImagenPipe implements PipeTransform {
  
  URL = "https://image.tmdb.org/t/p";

  transform(imagen: string, size: string='w500'): string {
    if (!imagen){
      return;
    }

    const imgURL = `${this.URL}/${size}${imagen}`;
    console.log('URL', imgURL);
    return imgURL;
  }

}
