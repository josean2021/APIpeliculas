import { ImagenPipe } from './imagen.pipe';

describe('ImagenPipe', () => {
  it('create an instance', () => {
    const pipe = new ImagenPipe();
    expect(pipe).toBeTruthy();
  });
});
